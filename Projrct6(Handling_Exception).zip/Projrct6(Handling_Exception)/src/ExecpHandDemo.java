import java.util.Scanner;

public class ExecpHandDemo {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		try {
			System.out.print("Enter the numerator: ");
			int numerator = scanner.nextInt();

			System.out.print("Enter the denominator: ");
			int denominator = scanner.nextInt();

			float result = numerator / denominator;
			System.out.println("Result: " + result);
		} catch (ArithmeticException e) {
			System.out.println("ArithmeticException caught: " + e.getMessage());
		} catch (Exception e) {
			System.out.println("Exception caught: " + e.getMessage());
		} finally {
			System.out.println("Finally block executed.");
		}

		scanner.close();
	}

	
}
