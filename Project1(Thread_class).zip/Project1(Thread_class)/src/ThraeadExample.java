// Extending Thread class
class MyThread extends Thread {
    public void run() {
        System.out.println("Thread created by extending Thread class.");
    }
}

// Implementing Runnable interface
class MyRunnable implements Runnable {
    public void run() {
        System.out.println("Thread created by implementing Runnable interface.");
    }
}
public class ThraeadExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Creating and starting thread using extended Thread class
        MyThread thread1 = new MyThread();
        thread1.start();

        // Creating and starting thread using implemented Runnable interface
        MyRunnable myRunnable = new MyRunnable();
        Thread thread2 = new Thread(myRunnable);
        thread2.start();
	}

}
