import java.util.Arrays;

public class Right_Rotate {
	public static void rightRotate(int[] arr, int steps) {
		int n = arr.length;
		int[] rotatedArr = new int[n];

		// Adjusting for steps larger than array length
		steps = steps % n;

		// Copying elements from original array to rotated array
		for (int i = 0; i < n; i++) {
			rotatedArr[(i + steps) % n] = arr[i];
		}

		// Copying elements from rotated array back to original array
		for (int i = 0; i < n; i++) {
			arr[i] = rotatedArr[i];
		}
	}

	public static void main(String[] args) {
		int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9};
		int steps = 5;

		System.out.println("Original Array: " + Arrays.toString(arr));

		rightRotate(arr, steps);

		System.out.println("Right Rotated Array: " + Arrays.toString(arr));
	}
}
