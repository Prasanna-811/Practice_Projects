class privateAS
{
	private String name;
	// getter method
    public String getName() {
        return this.name;
    }
    // setter method
    public void setName(String name) {
        this.name= name;
    }
}
public class accessSpecifier2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Private Access Specifier");
		privateAS obj = new privateAS();
		obj.setName("Mphasis.Ltd");
		System.out.println(obj.getName());
		
	}

}
