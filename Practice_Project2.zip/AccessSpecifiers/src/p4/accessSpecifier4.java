package p4;
import p3.publicAS;
public class accessSpecifier4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		publicAS obj = new publicAS();
		obj.display();
	}

}
