class defAccessSpecifier
{
	void display()
	{
		System.out.println("You are using the Default Access Specifier");
	}
}
public class accessSpecifiers1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Default Access Modifier");
		defAccessSpecifier das = new defAccessSpecifier();
		das.display();
	}

}

