package p2;

public class accessSpecifier3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
