package p1;

public class protectedAS {

}
