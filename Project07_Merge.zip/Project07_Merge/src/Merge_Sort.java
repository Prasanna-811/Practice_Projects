public class Merge_Sort {
	public static void mergeSort(int[] arr) {
		if (arr == null || arr.length <= 1) {
			return; // Base case: the array is already sorted or empty
		}

		int mid = arr.length / 2;

		// Create left and right subarrays
		int[] left = new int[mid];
		int[] right = new int[arr.length - mid];

		// Populate left and right subarrays
		for (int i = 0; i < mid; i++) {
			left[i] = arr[i];
		}
		for (int i = mid; i < arr.length; i++) {
			right[i - mid] = arr[i];
		}

		// Recursively sort the left and right subarrays
		mergeSort(left);
		mergeSort(right);

		// Merge the sorted subarrays
		merge(arr, left, right);
	}

	public static void merge(int[] arr, int[] left, int[] right) {
		int i = 0; // Index for the left subarray
		int j = 0; // Index for the right subarray
		int k = 0; // Index for the merged array

		while (i < left.length && j < right.length) {
			if (left[i] <= right[j]) {
				arr[k] = left[i];
				i++;
			} else {
				arr[k] = right[j];
				j++;
			}
			k++;
		}

		// Copy the remaining elements from the left subarray, if any
		while (i < left.length) {
			arr[k] = left[i];
			i++;
			k++;
		}

		// Copy the remaining elements from the right subarray, if any
		while (j < right.length) {
			arr[k] = right[j];
			j++;
			k++;
		}
	}

	public static void main(String[] args) {
		int[] arr = {10, 5, 8, 2, 3};

		System.out.println("Original array:");
		for (int num : arr) {
			System.out.print(num + " ");
		}

		mergeSort(arr);

		System.out.println("\nSorted array:");
		for (int num : arr) {
			System.out.print(num + " ");
		}
	}
}
