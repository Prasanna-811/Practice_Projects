
public class InnerClassVerifier {
	private static class InnerClassAssisted1 {
		private String msg = "Welcome to Java";
		class Inner {
		void hello() {
		System.out.println(msg + ", Let us start learning Inner Classes");
		 }}}
		private static class InnerClassAssisted2 {
		private String msg = "Inner Classes";
		void display() {
		class Inner {
		void msg() {
		System.out.println(msg);
		 }}
		Inner l = new Inner();
		l.msg();
		}}
		public static abstract class AnonymousInnerClass {
		public abstract void display();
		}
		public static void main(String[] args)
		{
		InnerClassAssisted1.Inner inner1 = new InnerClassAssisted1().new Inner();
		inner1.hello();
		InnerClassAssisted2 inner2 = new InnerClassAssisted2();
		inner2.display();
		AnonymousInnerClass anonymousInnerClass = new AnonymousInnerClass() {
		 public void display() 
		 {
		 System.out.println("Anonymous Inner Class");
		 }
		};anonymousInnerClass.display();
}
}