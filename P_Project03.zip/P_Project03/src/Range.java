public class Range {
	public static int findSumInRange(int[] arr, int L, int R) {
		if (arr == null || L < 0 || R >= arr.length || L > R) {
			System.out.println("Invalid input!");
			return -1;
		}

		int sum = 0;
		for (int i = L; i <= R; i++) {
			sum += arr[i];
		}

		return sum;
	}

	public static void main(String[] args) {
		int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9};
		int L = 2;
		int R = 5;

		int sum = findSumInRange(arr, L, R);

		if (sum != -1) {
			System.out.println("Sum of elements from index " + L + " to " + R + ": " + sum);
		}
	}
}
