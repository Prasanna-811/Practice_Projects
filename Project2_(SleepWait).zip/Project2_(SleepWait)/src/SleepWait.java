
public class SleepWait {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread sleepThread = new Thread(new SleepThread());
        Thread waitThread = new Thread(new WaitThread());

        sleepThread.start();
        waitThread.start();
	}

}
class SleepThread implements Runnable {
    public void run() {
        try {
            System.out.println("SleepThread is going to sleep.");
            Thread.sleep(3000); // Sleep for 3 seconds
            System.out.println("SleepThread has woken up.");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
class WaitThread implements Runnable {
    public void run() {
        synchronized (this) {
            try {
                System.out.println("WaitThread is waiting.");
                wait(3000); // Wait for 3 seconds
                System.out.println("WaitThread has been notified.");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}