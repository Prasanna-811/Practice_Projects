import java.util.Arrays;

public class Unsorted {
	public static int findFourthSmallest(int[] arr) {
		if (arr.length < 4) {
			System.out.println("Error: List contains less than 4 elements.");
			return -1;
		}

		Arrays.sort(arr); // Sort the array in ascending order

		return arr[3]; // Return the fourth smallest element
	}

	public static void main(String[] args) {
		int[] arr = {9, 2, 7, 5, 1, 8, 3, 6, 4};

		int fourthSmallest = findFourthSmallest(arr);

		System.out.println("The fourth smallest element is: " + fourthSmallest);
	}
}
