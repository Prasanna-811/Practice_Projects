class Node {
	int data;
	Node prev;
	Node next;

	public Node(int data) {
		this.data = data;
		this.prev = null;
		this.next = null;
	}
}

public class Doubley_LL {
	private Node head;

	public Doubley_LL() {
		this.head = null;
	}

	public void insert(int data) {
		Node newNode = new Node(data);

		if (head == null) {
			head = newNode;
		} else {
			Node current = head;
			while (current.next != null) {
				current = current.next;
			}
			current.next = newNode;
			newNode.prev = current;
		}
	}

	public void traverseForward() {
		if (head == null) {
			System.out.println("Doubly linked list is empty.");
			return;
		}

		Node current = head;
		System.out.print("Forward traversal: ");
		while (current != null) {
			System.out.print(current.data + " ");
			current = current.next;
		}
		System.out.println();
	}

	public void traverseBackward() {
		if (head == null) {
			System.out.println("Doubly linked list is empty.");
			return;
		}

		Node current = head;
		while (current.next != null) {
			current = current.next;
		}

		System.out.print("Backward traversal: ");
		while (current != null) {
			System.out.print(current.data + " ");
			current = current.prev;
		}
		System.out.println();
	}

	public static void main(String[] args) {
		Doubley_LL list = new Doubley_LL();

		list.insert(5);
		list.insert(10);
		list.insert(15);
		list.insert(20);
		list.insert(25);

		list.traverseForward();
		list.traverseBackward();
	}
}
