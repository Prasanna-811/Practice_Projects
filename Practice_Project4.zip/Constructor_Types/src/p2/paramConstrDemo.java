package p2;

public class paramConstrDemo {

}
