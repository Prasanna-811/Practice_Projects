package p1;

public class constructorTypes {

}
